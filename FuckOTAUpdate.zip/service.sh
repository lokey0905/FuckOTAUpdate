#!/system/bin/sh

MODDIR=${0%/*}
LOGFILE="$MODDIR/disable_ota.log"

log_print() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOGFILE"
}

disable_ota_components() {
    # 隱藏 Pixel Factory OTA 套件（若存在）
    pm uninstall -k --user 0 com.google.android.factoryota >/dev/null 2>&1

    # GMS
    pm disable-user --user 0 com.google.android.gms/.update.SystemUpdateActivity >/dev/null 2>&1
    pm disable-user --user 0 com.google.android.gms/.update.SystemUpdateService >/dev/null 2>&1
    pm disable-user --user 0 com.google.android.gms/.update.SystemUpdateService\$ActiveReceiver >/dev/null 2>&1
    pm disable-user --user 0 com.google.android.gms/.update.SystemUpdateService\$Receiver >/dev/null 2>&1
    pm disable-user --user 0 com.google.android.gms/.update.SystemUpdateService\$SecretCodeReceiver >/dev/null 2>&1

    # GSF
    pm disable-user --user 0 com.google.android.gsf/.update.SystemUpdateActivity >/dev/null 2>&1
    pm disable-user --user 0 com.google.android.gsf/.update.SystemUpdatePanoActivity >/dev/null 2>&1
    pm disable-user --user 0 com.google.android.gsf/.update.SystemUpdateService >/dev/null 2>&1
    pm disable-user --user 0 com.google.android.gsf/.update.SystemUpdateService\$Receiver >/dev/null 2>&1
    pm disable-user --user 0 com.google.android.gsf/.update.SystemUpdateService\$SecretCodeReceiver >/dev/null 2>&1
}

# 等待開機完成
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

sleep 20
log_print "boot completed, applying OTA block"
disable_ota_components

# 持續檢查，避免 GMS/GSF 更新後又被打開
while true; do
    sleep 300

    # 若元件被重新啟用，就再停用一次
    if dumpsys package com.google.android.gms 2>/dev/null | grep -q "SystemUpdateService"; then
        disable_ota_components
        log_print "re-applied OTA block"
    fi
done