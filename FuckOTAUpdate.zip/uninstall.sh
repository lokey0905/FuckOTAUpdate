#!/system/bin/sh

while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

sleep 10

# 還原 factoryota
cmd package install-existing --user 0 com.google.android.factoryota >/dev/null 2>&1

# 還原 GMS
pm enable --user 0 com.google.android.gms/.update.SystemUpdateActivity >/dev/null 2>&1
pm enable --user 0 com.google.android.gms/.update.SystemUpdateService >/dev/null 2>&1
pm enable --user 0 com.google.android.gms/.update.SystemUpdateService\$ActiveReceiver >/dev/null 2>&1
pm enable --user 0 com.google.android.gms/.update.SystemUpdateService\$Receiver >/dev/null 2>&1
pm enable --user 0 com.google.android.gms/.update.SystemUpdateService\$SecretCodeReceiver >/dev/null 2>&1

# 還原 GSF
pm enable --user 0 com.google.android.gsf/.update.SystemUpdateActivity >/dev/null 2>&1
pm enable --user 0 com.google.android.gsf/.update.SystemUpdatePanoActivity >/dev/null 2>&1
pm enable --user 0 com.google.android.gsf/.update.SystemUpdateService >/dev/null 2>&1
pm enable --user 0 com.google.android.gsf/.update.SystemUpdateService\$Receiver >/dev/null 2>&1
pm enable --user 0 com.google.android.gsf/.update.SystemUpdateService\$SecretCodeReceiver >/dev/null 2>&1